$src = "c:\Users\Paul Davies\Downloads\hospitality-hive-nextjs\hospitality-hive-nextjs"
$dest = Join-Path $src "hex-recruitment.zip"
if (Test-Path $dest) { Remove-Item $dest }
$files = Get-ChildItem -Path $src -Recurse -File | Where-Object { $_.FullName -notmatch '\\(node_modules|\.next|\.git)\\' }
$files | Compress-Archive -DestinationPath $dest -Force
Write-Host "Created $dest"
